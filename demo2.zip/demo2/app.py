import json
import os
from datetime import datetime

import streamlit as st

from llm import extract_fields
from matcher import find_matches
from utils import mask_phone, time_diff, format_time
from i18n import t, get_lang, set_lang, STRINGS

DATA_FILE = "data.json"


def load_data() -> list:
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def save_data(data: list) -> None:
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def render_record_card(r: dict) -> None:
    with st.container(border=True):
        st.markdown(f"**{r.get('item', '未知')}** · {r.get('features', '未知')}")
        st.caption(
            f"📍 {r.get('location', '未知')} · "
            f"🕒 {format_time(r.get('time', '未知'))} "
            f"({time_diff(r.get('time', '未知'))})"
        )
        st.caption(f"📞 {mask_phone(r.get('contact', '未知'))}")


def main():
    st.set_page_config(page_title=t("page_title"), page_icon="🔍", layout="wide")
    st.title(t("title"))
    st.caption(t("caption"))

    with st.sidebar:
        st.header(t("settings"))
        lang = st.selectbox(
            t("lang_label"),
            list(STRINGS.keys()),
            format_func=lambda x: "中文" if x == "zh" else "English",
            key="lang_select",
        )
        set_lang(lang)
        st.caption(t("lang_switch_note"))
        threshold = st.slider(t("threshold"), 0.0, 1.0, 0.5, 0.05)
        top_k = st.slider(t("top_k"), 1, 20, 5)
        st.divider()
        if st.button(t("clear_btn"), use_container_width=True):
            save_data([])
            st.success(t("cleared"))
            st.rerun()

    tab_input, tab_list, tab_match = st.tabs(
        [t("tab_input"), t("tab_list"), t("tab_match")]
    )

    with tab_input:
        st.subheader(t("nl_header"))
        st.markdown(t("nl_desc"))
        examples = t("examples")
        example = st.selectbox(
            t("example_label"),
            examples,
            index=None,
            placeholder=t("example_ph"),
        )

        text = st.text_area(t("desc_label"), value=example or "", height=120)

        if st.button(t("extract_btn"), type="primary", use_container_width=True):
            if not text.strip():
                st.warning(t("warn_empty"))
            else:
                with st.spinner(t("spinner_extract")):
                    fields = extract_fields(text)
                if fields["type"] not in ("lost", "found"):
                    st.warning(t("warn_type"))
                    fields["type"] = st.selectbox(t("type_label"), ["lost", "found"])
                st.success(t("extract_done"))
                st.json(fields, expanded=False)
                fields["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                data = load_data()
                data.append(fields)
                save_data(data)
                st.balloons()

    with tab_list:
        data = load_data()
        if not data:
            st.info(t("list_empty"))
        else:
            lost = [r for r in data if r.get("type") == "lost"]
            found = [r for r in data if r.get("type") == "found"]
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"### {t('lost_header', n=len(lost))}")
                for r in lost:
                    render_record_card(r)
            with col2:
                st.markdown(f"### {t('found_header', n=len(found))}")
                for r in found:
                    render_record_card(r)

    with tab_match:
        data = load_data()
        if len(data) < 2:
            st.info(t("match_need_more"))
            return
        st.subheader(t("match_header"))
        options = []
        for i, r in enumerate(data):
            tag = t("match_tag_lost") if r.get("type") == "lost" else t("match_tag_found")
            options.append(f"#{i} [{tag}] {r.get('item', '未知')}")
        selected = st.selectbox(t("match_select"), options)
        if selected:
            idx = int(selected.split("#")[1].split(" ")[0])
            record = data[idx]
            with st.spinner(t("spinner_match")):
                matches = find_matches(record, data, threshold=threshold, top_k=top_k)
            if not matches:
                st.warning(t("match_none"))
            else:
                for m in matches:
                    rec = m["record"]
                    score = m["score"]
                    with st.container(border=True):
                        tag = t("match_tag_lost") if rec.get("type") == "lost" else t("match_tag_found")
                        st.markdown(f"### {tag}：**{rec.get('item', '未知')}**")
                        st.markdown(t("match_total", p=score["total"]))
                        with st.expander(t("match_detail")):
                            for k, v in score["scores"].items():
                                st.text(
                                    f"{k}: {v:.4f} (权重 {score['weights'][k]:.0%})"
                                )
                        st.caption(
                            f"📍 {rec.get('location', '未知')} · "
                            f"🕒 {format_time(rec.get('time', '未知'))}"
                        )
                        st.caption(f"📞 {mask_phone(rec.get('contact', '未知'))}")


if __name__ == "__main__":
    main()
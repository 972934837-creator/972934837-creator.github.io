// 共享抽取逻辑：支持中英双语的物品/地点/联系方式识别
const ITEMS = {
  'phone': '手机', 'cellphone': '手机', 'mobile': '手机', '手机': '手机',
  'earphones': '蓝牙耳机', 'headphones': '蓝牙耳机', 'airpods': '蓝牙耳机', '耳机': '蓝牙耳机',
  'keys': '钥匙串', '钥匙': '钥匙串',
  'wallet': '钱包', 'purse': '钱包', '钱包': '钱包',
  'card': '校园卡', '校园卡': '校园卡', '卡': '校园卡',
  'bag': '书包', 'backpack': '书包', '书包': '帆布书包',
  'book': '课本', '书': '课本', '课本': '课本',
  'cup': '保温杯', 'bottle': '保温杯', 'thermos': '保温杯', '杯': '保温杯',
  'umbrella': '雨伞', '伞': '雨伞',
  'watch': '手表', '手表': '手表',
  'laptop': '电脑', 'computer': '电脑', '电脑': '电脑',
  'tablet': '平板', 'ipad': '平板', 'pad': '平板'
};

const LOCS = {
  'library': '图书馆', '图书馆': '图书馆',
  'canteen': '食堂', 'cafeteria': '食堂', 'dining hall': '食堂', '食堂': '食堂',
  'classroom': '教学楼', 'teaching building': '教学楼', '教学楼': '教学楼',
  'playground': '操场', 'field': '操场', '操场': '操场',
  'study room': '自习室', 'self-study room': '自习室', '自习室': '自习室',
  'dorm': '宿舍', 'dormitory': '宿舍', '宿舍': '宿舍',
  'lab': '实验室', 'laboratory': '实验室', '实验室': '实验室',
  'gym': '体育馆', 'gymnasium': '体育馆', '体育馆': '体育馆'
};

// 英文非名词停用词（冠词/介词/代词/动词/助动词/形容词/连词/副词）
const EN_STOP = new Set([
  'i','my','me','mine','a','an','the','this','that','these','those',
  'lost','lose','losing','found','find','finding','dropped','drop','left','leave','leaving',
  'in','on','at','near','inside','by','of','to','from','with','under','over','between',
  'is','was','are','were','be','been','being','have','has','had','do','did','does',
  'yesterday','today','tomorrow','morning','afternoon','evening','night','now','then',
  'and','or','but','so','because','if','when','while','it','its','they','them','their','he','she','his','her',
  'very','just','also','only','some','any','no','not','too','again','please','contact','phone','wechat','email',
  'black','white','blue','red','green','yellow','pink','gray','grey','brown','orange','purple','silver','gold',
  'new','old','big','small','our','your'
]);

// 中文动词/量词/代词/方位/时间等非名词成分（用于剥离，保留名词核心）
const ZH_STRIP = /我|你|他|她|的|了|把|个|只|部|本|串|张|件|条|块|丢|掉|捡|落|忘|找|寻|在|上|下|里|中|外|边|旁|前|后|左|右|今天|昨天|明天|上午|下午|晚上|早上|联系|电话|手机号|微信|邮箱|学号|请|和|与|及|并|给|向|对|从|到|被|一|二|三|四|五|六|七|八|九|十/g;

function detectLang(text) {
  const letters = (text.match(/[a-zA-Z\u4e00-\u9fa5]/g) || []);
  if (!letters.length) return 'zh';
  const latin = letters.filter(c => /[a-zA-Z]/.test(c)).length;
  return latin / letters.length > 0.5 ? 'en' : 'zh';
}

function maskPhone(p) {
  const d = p.replace(/\D/g, '');
  return d.length >= 7 ? d.slice(0, 3) + '****' + d.slice(-4) : p;
}

// 按语法名词识别物品：英文取名词性词，中文取剥离非名词后的核心名词
function extractItem(text) {
  const lang = detectLang(text);
  if (lang === 'en') {
    const lower = text.toLowerCase();
    for (const k of Object.keys(ITEMS)) {
      if (/^[a-z]/.test(k) && lower.includes(k)) return ITEMS[k];
    }
    const tokens = lower.match(/[a-z]+/g) || [];
    const nouns = tokens.filter(t => !EN_STOP.has(t) && t.length > 1);
    if (nouns.length) {
      return ITEMS[nouns[0]] || nouns[0];
    }
  }
  for (const k in ITEMS) {
    if (/[\u4e00-\u9fa5]/.test(k) && text.includes(k)) return ITEMS[k];
  }
  const core = text.replace(ZH_STRIP, '').replace(/[0-9a-zA-Z\s，。、,.\!！？?：:；;（）()【】\[\]]/g, '').trim();
  if (core) {
    const m = core.match(/[\u4e00-\u9fa5]{1,6}/);
    if (m) return m[0];
  }
  return '未知';
}

function extractLocation(text) {
  const lang = detectLang(text);
  if (lang === 'en') {
    const lower = text.toLowerCase();
    const m = lower.match(/\b(?:in|at|near|on|inside|by)\s+([a-z\s]{2,25})/i);
    if (m) {
      const phrase = m[1].trim();
      if (LOCS[phrase]) return LOCS[phrase];
      for (const k of Object.keys(LOCS)) {
        if (/^[a-z]/.test(k) && phrase.includes(k)) return LOCS[k];
      }
    }
    for (const k of Object.keys(LOCS)) {
      if (/^[a-z]/.test(k) && lower.includes(k)) return LOCS[k];
    }
  }
  for (const k in LOCS) {
    if (/[\u4e00-\u9fa5]/.test(k) && text.includes(k)) return LOCS[k];
  }
  return '未知';
}

function extractContact(text) {
  const phone = (text.match(/1[3-9]\d{9}/) || ['未知'])[0];
  if (phone !== '未知') return maskPhone(phone);
  if (text.includes('微信') || /wechat/i.test(text)) {
    const m = text.match(/(?:微信|wechat)\s*[:：]?\s*([A-Za-z0-9_\u4e00-\u9fa5]+)/i);
    return m ? '微信 ' + m[1] : '微信（已记录）';
  }
  return '未知';
}

function extractFields(text, type) {
  const lang = detectLang(text);
  const item = extractItem(text);
  const location = extractLocation(text);
  const contact = extractContact(text);
  return {
    type: type,
    item: item,
    features: '见描述（AI 已识别）',
    location: location,
    time: '今天',
    contact: contact,
    lang: lang
  };
}
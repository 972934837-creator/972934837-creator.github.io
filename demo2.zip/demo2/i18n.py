import streamlit as st

STRINGS = {
    "zh": {
        "page_title": "寻物智联",
        "title": "🔍 寻物智联 · 校园失物招领智能匹配",
        "caption": "基于大模型信息抽取 + 智能匹配打分的校园失物招领平台",
        "settings": "⚙️ 设置",
        "lang_label": "界面语言",
        "threshold": "匹配阈值",
        "top_k": "返回匹配数",
        "clear_btn": "🗑️ 清空数据",
        "cleared": "已清空",
        "tab_input": "📝 信息录入",
        "tab_list": "📋 记录列表",
        "tab_match": "🎯 智能匹配",
        "nl_header": "自然语言录入",
        "nl_desc": "直接用自然语言描述失物或招领信息，AI 将自动抽取关键字段。",
        "example_label": "示例",
        "example_ph": "选择示例填充...",
        "examples": [
            "我今天在图书馆三楼丢了一个黑色的华为手机，联系电话13812345678",
            "昨天下午在二食堂捡到一个蓝色帆布书包，联系微信zhangsan",
            "在操场丢了一串钥匙，带小熊挂件，电话13987654321",
        ],
        "desc_label": "描述信息",
        "extract_btn": "🤖 AI 抽取并保存",
        "warn_empty": "请输入描述信息",
        "spinner_extract": "AI 抽取中...",
        "warn_type": "未能识别类型，请手动选择",
        "type_label": "类型",
        "extract_done": "抽取完成",
        "list_empty": "暂无记录，先去「信息录入」添加吧",
        "lost_header": "📦 失物记录（{n}）",
        "found_header": "🤝 招领记录（{n}）",
        "match_need_more": "至少需要 2 条记录才能匹配",
        "match_header": "为指定记录查找匹配",
        "match_select": "选择记录",
        "spinner_match": "匹配中...",
        "match_none": "未找到匹配记录，可尝试调低匹配阈值",
        "match_tag_lost": "失物",
        "match_tag_found": "招领",
        "match_total": "**匹配总分：{p:.2%}**",
        "match_detail": "详细得分",
        "lang_switch_note": "切换语言后界面文本将同步切换，AI 抽取支持中英文输入",
    },
    "en": {
        "page_title": "FindLink",
        "title": "🔍 FindLink · Campus Lost & Found Smart Matching",
        "caption": "Powered by LLM information extraction + smart matching scoring",
        "settings": "⚙️ Settings",
        "lang_label": "UI Language",
        "threshold": "Match threshold",
        "top_k": "Top K results",
        "clear_btn": "🗑️ Clear data",
        "cleared": "Cleared",
        "tab_input": "📝 Input",
        "tab_list": "📋 Records",
        "tab_match": "🎯 Smart Match",
        "nl_header": "Natural Language Input",
        "nl_desc": "Describe lost or found items in natural language; AI extracts key fields automatically.",
        "example_label": "Example",
        "example_ph": "Pick an example to fill...",
        "examples": [
            "I lost my black Huawei phone on the 3rd floor of the library today, contact 13812345678",
            "I found a blue canvas backpack in canteen 2 yesterday afternoon, WeChat zhangsan",
            "I lost a bunch of keys with a bear charm on the playground, phone 13987654321",
        ],
        "desc_label": "Description",
        "extract_btn": "🤖 AI extract & save",
        "warn_empty": "Please enter a description",
        "spinner_extract": "AI extracting...",
        "warn_type": "Could not detect type, please choose manually",
        "type_label": "Type",
        "extract_done": "Extraction done",
        "list_empty": "No records yet. Add one in the Input tab.",
        "lost_header": "📦 Lost records ({n})",
        "found_header": "🤝 Found records ({n})",
        "match_need_more": "At least 2 records are required to match",
        "match_header": "Find matches for a record",
        "match_select": "Select record",
        "spinner_match": "Matching...",
        "match_none": "No match found. Try lowering the threshold.",
        "match_tag_lost": "Lost",
        "match_tag_found": "Found",
        "match_total": "**Match total: {p:.2%}**",
        "match_detail": "Score details",
        "lang_switch_note": "Switching language updates the UI. AI extraction supports both Chinese and English input.",
    },
}


def get_lang() -> str:
    return st.session_state.get("lang", "zh")


def set_lang(lang: str) -> None:
    st.session_state["lang"] = lang if lang in STRINGS else "zh"


def t(key: str, **kwargs) -> str:
    lang = get_lang()
    value = STRINGS[lang].get(key, STRINGS["zh"].get(key, key))
    if kwargs:
        value = value.format(**kwargs)
    return value
import os
import json
import re

import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(_env_path):
        with open(_env_path, "r", encoding="utf-8") as _f:
            for _line in _f:
                _line = _line.strip()
                if not _line or _line.startswith("#") or "=" not in _line:
                    continue
                _k, _v = _line.split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))

API_URL = "https://api.deepseek.com/v1/chat/completions"
MODEL_NAME = "deepseek-chat"
TIMEOUT_SECONDS = 30

SYSTEM_PROMPT = (
    '你是校园失物招领信息抽取助手，支持中文与英文输入。\n'
    '抽取步骤：\n'
    '1) 自动检测输入语言（zh/en），填入 lang 字段。\n'
    '2) 英文输入用语法分析识别：名词短语→item；地点介词短语\n'
    '   (in/at/near/on/inside + NP)→location；颜色/品牌形容词→features；\n'
    '   时间短语(yesterday/today/Oct 28等)→time。\n'
    '3) 中文输入用语法分析识别：名词→item；"在…"+地点状语/方位词→location；\n'
    '   颜色/品牌形容词→features。\n'
    '4) 字段值统一归一化为中文规范词，使用以下对照表（不区分大小写）：\n'
    '   物品：phone/cellphone/mobile→手机，earphones/headphones→蓝牙耳机，\n'
    '         keys→钥匙串，wallet/purse→钱包，card→校园卡，\n'
    '         bag/backpack→书包，book→课本，cup/bottle/thermos→保温杯，\n'
    '         umbrella→雨伞，watch→手表，laptop/computer→电脑，tablet/ipad→平板；\n'
    '   地点：library→图书馆，canteen/cafeteria/dining hall→食堂，\n'
    '         classroom/teaching building→教学楼，playground/field→操场，\n'
    '         study room/self-study room→自习室，dorm/dormitory→宿舍，\n'
    '         lab/laboratory→实验室，gym/gymnasium→体育馆。\n'
    '5) time 尽量标准化为 YYYY-MM-DD HH:MM，无法确定填"未知"。\n'
    '输出字段：type("lost"或"found")、item、features、location、time、\n'
    '         contact、description(原始输入)、lang("zh"或"en")。\n'
    '只输出JSON，不要解释。若字段缺失填"未知"。'
)

DEFAULT_FIELDS = {
    "type": "未知",
    "item": "未知",
    "features": "未知",
    "location": "未知",
    "time": "未知",
    "contact": "未知",
    "description": "未知",
    "lang": "zh",
}


def _detect_lang(text: str) -> str:
    """轻量语言检测：含拉丁字母占比高判定为英文，否则中文。"""
    if not text:
        return "zh"
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return "zh"
    latin = sum(1 for c in letters if c.isascii())
    return "en" if latin / len(letters) > 0.5 else "zh"


def _default_result(description: str) -> dict:
    """构造字段全部为 "未知" 的兜底结果，description 保留原始输入。"""
    result = dict(DEFAULT_FIELDS)
    result["description"] = description if description else "未知"
    result["lang"] = _detect_lang(description)
    return result


def _parse_json(text: str) -> dict | None:
    """从模型输出中解析 JSON，兼容裸 JSON、代码块、混杂文本三种情况。"""
    if not text:
        return None
    text = text.strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass

    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    return None


def _call_api(text: str) -> str:
    """调用 DeepSeek 官方 API，返回模型文本内容。

    任何异常（缺 Key、网络错误、非 200、结构异常）均抛出，由上层兜底。
    """
    api_key = os.environ.get("MAAS_API_KEY")
    if not api_key:
        raise RuntimeError("环境变量 MAAS_API_KEY 未设置")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": text},
        ],
        "temperature": 0.1,
        "stream": False,
    }

    response = requests.post(API_URL, headers=headers, json=payload, timeout=TIMEOUT_SECONDS)
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"]


def extract_fields(text: str) -> dict:
    """从用户输入中抽取失物招领结构化字段。

    调用 DeepSeek 官方 API 进行信息抽取。
    API 失败、JSON 解析失败或字段异常时，返回字段全部为 "未知" 的默认 JSON，
    其中 description 保留原始输入文本，保证调用方总能拿到结构一致的结果。
    """
    if not text or not text.strip():
        return _default_result(text or "")

    try:
        content = _call_api(text)
    except Exception:
        return _default_result(text)

    parsed = _parse_json(content)
    if not isinstance(parsed, dict):
        return _default_result(text)

    result = _default_result(text)
    for key in DEFAULT_FIELDS:
        if key not in parsed:
            continue
        value = parsed[key]
        if value is None:
            continue
        if isinstance(value, str):
            value = value.strip()
            if not value:
                continue
        result[key] = value

    result["description"] = text
    return result


if __name__ == "__main__":
    import sys

    sample = (
        sys.argv[1]
        if len(sys.argv) > 1
        else "我今天在图书馆三楼丢了一个黑色的华为手机，联系电话13812345678"
    )
    print(json.dumps(extract_fields(sample), ensure_ascii=False, indent=2))
import re
from datetime import datetime
from difflib import SequenceMatcher


def _text_similarity(a: str, b: str) -> float:
    """计算两个字符串的编辑相似度（0-1）。"""
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def _keyword_overlap(a: str, b: str) -> float:
    """基于分词的 Jaccard 关键词重叠度（0-1）。"""
    if not a or not b:
        return 0.0
    tokens_a = set(re.findall(r"[\w]+", a.lower()))
    tokens_b = set(re.findall(r"[\w]+", b.lower()))
    if not tokens_a or not tokens_b:
        return 0.0
    return len(tokens_a & tokens_b) / len(tokens_a | tokens_b)


def _field_similarity(a: str, b: str) -> float:
    """字段综合相似度：取编辑相似度与关键词重叠度的较大值。"""
    return max(_text_similarity(a, b), _keyword_overlap(a, b))


def _time_proximity(a: str, b: str) -> float:
    """计算时间接近度，越接近分数越高。

    - 任一时间为 "未知" 给 0.5（中性分，不奖不罚）
    - 24 小时内满分 1.0
    - 24~72 小时线性衰减到 0.5
    - 72~168 小时线性衰减到 0.0
    - 超过 7 天 0.0
    """
    if not a or not b or a == "未知" or b == "未知":
        return 0.5

    formats = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"]
    ta = tb = None
    for fmt in formats:
        if ta is None:
            try:
                ta = datetime.strptime(a.strip(), fmt)
            except ValueError:
                pass
        if tb is None:
            try:
                tb = datetime.strptime(b.strip(), fmt)
            except ValueError:
                pass
    if ta is None or tb is None:
        return 0.5

    diff_hours = abs((ta - tb).total_seconds()) / 3600
    if diff_hours <= 24:
        return 1.0
    if diff_hours <= 72:
        return 1.0 - (diff_hours - 24) / 48 * 0.5
    if diff_hours <= 168:
        return 0.5 - (diff_hours - 72) / 96 * 0.5
    return 0.0


WEIGHTS = {
    "item": 0.4,
    "features": 0.25,
    "location": 0.2,
    "time": 0.15,
}


def match_score(lost: dict, found: dict) -> dict:
    """计算失物与招领记录的匹配分数。

    Args:
        lost: 失物记录
        found: 招领记录

    Returns:
        {"total": 加权总分, "scores": 各维度得分, "weights": 权重}
    """
    scores = {
        "item": _field_similarity(lost.get("item", ""), found.get("item", "")),
        "features": _field_similarity(lost.get("features", ""), found.get("features", "")),
        "location": _field_similarity(lost.get("location", ""), found.get("location", "")),
        "time": _time_proximity(lost.get("time", ""), found.get("time", "")),
    }
    total = sum(scores[k] * WEIGHTS[k] for k in WEIGHTS)
    return {
        "total": round(total, 4),
        "scores": {k: round(v, 4) for k, v in scores.items()},
        "weights": WEIGHTS,
    }


def find_matches(
    record: dict,
    records: list,
    threshold: float = 0.5,
    top_k: int = 5,
) -> list:
    """为给定记录查找反向类型的匹配记录。

    Args:
        record: 待匹配记录（lost 找 found，found 找 lost）
        records: 候选记录列表
        threshold: 匹配阈值，低于此分不返回
        top_k: 返回前 k 个匹配

    Returns:
        [{"record": 匹配记录, "score": 分数详情}, ...] 按总分降序
    """
    record_type = record.get("type", "")
    target_type = "found" if record_type == "lost" else "lost"

    results = []
    for rec in records:
        if rec is record or rec.get("type") != target_type:
            continue
        if record_type == "lost":
            score = match_score(record, rec)
        else:
            score = match_score(rec, record)
        if score["total"] >= threshold:
            results.append({"record": rec, "score": score})

    results.sort(key=lambda x: x["score"]["total"], reverse=True)
    return results[:top_k]
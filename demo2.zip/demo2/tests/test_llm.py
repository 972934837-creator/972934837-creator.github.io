import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from llm import _detect_lang, _parse_json, _default_result, DEFAULT_FIELDS


def test_detect_lang_chinese():
    assert _detect_lang("我今天在图书馆丢了一部手机") == "zh"
    assert _detect_lang("在操场丢了一串钥匙") == "zh"


def test_detect_lang_english():
    assert _detect_lang("I lost my black Huawei phone in the library") == "en"
    assert _detect_lang("Found a blue backpack in canteen 2 yesterday") == "en"


def test_detect_lang_mixed():
    assert _detect_lang("在 library 丢了我的 phone") == "en"
    assert _detect_lang("丢了一个 phone") == "zh"


def test_detect_lang_empty():
    assert _detect_lang("") == "zh"
    assert _detect_lang("12345") == "zh"


def test_default_fields_has_lang():
    assert "lang" in DEFAULT_FIELDS
    assert DEFAULT_FIELDS["lang"] == "zh"


def test_default_result_preserves_lang():
    r_zh = _default_result("我在图书馆丢了手机")
    assert r_zh["lang"] == "zh"
    assert r_zh["description"] == "我在图书馆丢了手机"
    r_en = _default_result("I lost my phone in the library")
    assert r_en["lang"] == "en"
    for k in ("type", "item", "features", "location", "time", "contact"):
        assert r_en[k] == "未知"


def test_parse_json_bare():
    assert _parse_json('{"a": 1}') == {"a": 1}


def test_parse_json_codeblock():
    s = '```json\n{"item": "手机", "lang": "zh"}\n```'
    assert _parse_json(s) == {"item": "手机", "lang": "zh"}


def test_parse_json_mixed():
    s = '好的，结果如下：\n{"item": "phone", "lang": "en"}\n以上。'
    assert _parse_json(s) == {"item": "phone", "lang": "en"}


def test_parse_json_invalid():
    assert _parse_json("not json at all") is None
    assert _parse_json("") is None


if __name__ == "__main__":
    funcs = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for fn in funcs:
        try:
            fn()
            print(f"PASS {fn.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
    print(f"\n{passed}/{len(funcs)} passed")
    sys.exit(0 if passed == len(funcs) else 1)
import re
from datetime import datetime


def mask_phone(phone: str) -> str:
    """手机号打码，保留前3位和后4位，中间用 **** 替换。

    支持带分隔符的输入（如 138-1234-5678），仅对纯数字长度>=7的输入打码；
    非手机号输入（如微信、邮箱、短号）原样返回，避免误伤联系方式。
    """
    if not phone or not isinstance(phone, str):
        return phone or ""
    if phone == "未知":
        return phone
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 7:
        return phone
    return digits[:3] + "****" + digits[-4:]


def _parse_time(time_str: str) -> datetime | None:
    if not time_str or time_str == "未知":
        return None
    formats = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"]
    for fmt in formats:
        try:
            return datetime.strptime(time_str.strip(), fmt)
        except ValueError:
            continue
    return None


def time_diff(time_str: str, reference: datetime | None = None) -> str:
    """计算时间差，返回人类可读的相对时间描述。

    Args:
        time_str: 时间字符串，格式 YYYY-MM-DD HH:MM 或 YYYY-MM-DD
        reference: 参考时间，默认为当前时间

    Returns:
        如 "3小时前"、"2天前"；无法解析返回 "未知"。
    """
    target = _parse_time(time_str)
    if target is None:
        return "未知"
    if reference is None:
        reference = datetime.now()

    seconds = (reference - target).total_seconds()
    if seconds < 0:
        seconds = -seconds
        suffix = "后"
    else:
        suffix = "前"

    if seconds < 60:
        return "刚刚"
    if seconds < 3600:
        return f"{int(seconds // 60)}分钟{suffix}"
    if seconds < 86400:
        return f"{int(seconds // 3600)}小时{suffix}"
    if seconds < 2592000:
        return f"{int(seconds // 86400)}天{suffix}"
    if seconds < 31536000:
        return f"{int(seconds // 2592000)}个月{suffix}"
    return f"{int(seconds // 31536000)}年{suffix}"


def format_time(time_str: str) -> str:
    """标准化时间显示，未知值统一返回 "未知"。"""
    if not time_str or time_str == "未知":
        return "未知"
    return time_str.strip()